# This Python code was automatically generated from the following Metview Macro:
# /Users/cgr/metview//ctest/convert/myfunc_include.mv
# at: 2023-02-20 16:31:59

# Please note: 

import metview as mv

def my_func(a):
    
    return a + 1
    

